Public phishing corpus downloaded from http://monkey.org/~jose/wiki/doku.php?id=phishingcorpus (2015-02-01)
